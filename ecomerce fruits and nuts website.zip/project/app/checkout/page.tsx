'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Tag, Check, ShieldCheck, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useCart, formatINR } from '@/lib/cart-context';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Coupon } from '@/lib/types';
import { cn } from '@/lib/utils';

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clear } = useCart();
  const [form, setForm] = useState({
    customer_name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [couponCode, setCouponCode] = useState('');
  const [coupon, setCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');
  const [applying, setApplying] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (coupon) {
      setCoupon(null);
      setCouponError('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [couponCode]);

  const shipping = subtotal >= 999 ? 0 : 79;
  let discount = 0;
  if (coupon) {
    if (coupon.type === 'percentage') discount = Math.round((subtotal * Number(coupon.value)) / 100);
    else if (coupon.type === 'flat') discount = Math.min(Number(coupon.value), subtotal);
  }
  const finalShipping = coupon?.type === 'free_shipping' ? 0 : shipping;
  const total = Math.max(0, subtotal - discount) + finalShipping;

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    setApplying(true);
    setCouponError('');
    const { data, error } = await supabase
      .from('coupons')
      .select('*')
      .eq('code', couponCode.trim().toUpperCase())
      .eq('active', true)
      .maybeSingle();
    setApplying(false);
    if (error || !data) {
      setCoupon(null);
      setCouponError('Invalid or expired coupon code.');
      return;
    }
    const c = data as Coupon;
    if (c.min_order && subtotal < Number(c.min_order)) {
      setCoupon(null);
      setCouponError(`Minimum order of ${formatINR(Number(c.min_order))} required for this coupon.`);
      return;
    }
    if (c.expiry && new Date(c.expiry) < new Date()) {
      setCoupon(null);
      setCouponError('This coupon has expired.');
      return;
    }
    if (c.usage_limit && c.used_count >= c.usage_limit) {
      setCoupon(null);
      setCouponError('This coupon has reached its usage limit.');
      return;
    }
    setCoupon(c);
    toast.success('Coupon applied!', { description: c.code });
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }
    // basic validation
    for (const k of ['customer_name', 'email', 'phone', 'address', 'city', 'pincode'] as const) {
      if (!form[k].trim()) {
        toast.error('Please fill in all required fields');
        return;
      }
    }
    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      toast.error('Please enter a valid email address');
      return;
    }
    setSubmitting(true);
    const orderNumber = 'FN' + Date.now().toString().slice(-8);
    const payload = {
      order_number: orderNumber,
      customer_name: form.customer_name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      address: form.address.trim(),
      city: form.city.trim(),
      state: form.state.trim() || null,
      pincode: form.pincode.trim(),
      items: items.map((i) => ({
        product_id: i.product.id,
        name: i.product.name,
        slug: i.product.slug,
        price: Number(i.product.price),
        quantity: i.quantity,
        image_url: i.product.image_url,
        unit: i.product.unit,
      })),
      subtotal,
      discount,
      shipping: finalShipping,
      total,
      coupon_code: coupon?.code ?? null,
      payment_method: paymentMethod,
      status: 'pending',
    };
    const { error } = await supabase.from('orders').insert(payload);
    setSubmitting(false);
    if (error) {
      toast.error('Could not place order', { description: 'Please try again.' });
      return;
    }
    clear();
    router.push(`/order/success?o=${orderNumber}`);
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-2xl font-semibold">Your cart is empty</h1>
        <p className="mt-2 text-sm text-muted-foreground">Add some products before checking out.</p>
        <Button asChild className="mt-6">
          <Link href="/shop">Browse products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-3xl font-semibold sm:text-4xl">Checkout</h1>
      <form onSubmit={onSubmit} className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        {/* Left: details */}
        <div className="space-y-8">
          <section className="rounded-xl border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Contact &amp; Shipping</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label htmlFor="name">Full name *</Label>
                <Input id="name" value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="phone">Phone *</Label>
                <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="mt-1" required />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="address">Address *</Label>
                <Input id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="city">City *</Label>
                <Input id="city" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="state">State</Label>
                <Input id="state" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label htmlFor="pincode">Pincode *</Label>
                <Input id="pincode" value={form.pincode} onChange={(e) => setForm({ ...form, pincode: e.target.value })} className="mt-1" required />
              </div>
            </div>
          </section>

          <section className="rounded-xl border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Payment Method</h2>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mt-4 space-y-3">
              {[
                { value: 'cod', label: 'Cash on Delivery', desc: 'Pay when your order arrives' },
                { value: 'razorpay', label: 'Razorpay (UPI / Cards / Wallets)', desc: 'Secure online payment via Razorpay' },
                { value: 'stripe', label: 'Stripe (Cards)', desc: 'Visa, Mastercard, Amex via Stripe' },
              ].map((m) => (
                <label
                  key={m.value}
                  className={cn(
                    'flex cursor-pointer items-start gap-3 rounded-lg border p-4 transition',
                    paymentMethod === m.value ? 'border-primary bg-primary/5' : 'hover:bg-secondary/40'
                  )}
                >
                  <RadioGroupItem value={m.value} className="mt-1" />
                  <div>
                    <p className="text-sm font-medium">{m.label}</p>
                    <p className="text-xs text-muted-foreground">{m.desc}</p>
                  </div>
                </label>
              ))}
            </RadioGroup>
            <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5" /> Your payment information is encrypted and secure.
            </p>
          </section>
        </div>

        {/* Right: summary */}
        <aside className="lg:sticky lg:top-28 lg:self-start">
          <div className="rounded-xl border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Order Summary</h2>
            <div className="mt-4 max-h-64 space-y-3 overflow-y-auto pr-1">
              {items.map(({ product, quantity }) => (
                <div key={product.id} className="flex gap-3">
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-secondary">
                    <Image src={product.image_url} alt={product.name} fill sizes="56px" className="object-cover" />
                    <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                      {quantity}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="line-clamp-1 text-sm font-medium">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{formatINR(Number(product.price))} · {product.unit}</p>
                  </div>
                  <p className="text-sm font-semibold">{formatINR(Number(product.price) * quantity)}</p>
                </div>
              ))}
            </div>

            {/* Coupon */}
            <div className="mt-5 border-t pt-4">
              <Label className="text-xs uppercase tracking-wider">Coupon code</Label>
              <div className="mt-1.5 flex gap-2">
                <Input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder="WELCOME10"
                  className="uppercase"
                />
                <Button type="button" variant="secondary" onClick={applyCoupon} disabled={applying || !couponCode.trim()}>
                  {applying ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Apply'}
                </Button>
              </div>
              {couponError && <p className="mt-1.5 text-xs text-destructive">{couponError}</p>}
              {coupon && (
                <p className="mt-1.5 flex items-center gap-1.5 text-xs text-success">
                  <Check className="h-3.5 w-3.5" /> {coupon.code} applied
                </p>
              )}
            </div>

            {/* Totals */}
            <dl className="mt-4 space-y-2 border-t pt-4 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd>{formatINR(subtotal)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-success">
                  <dt>Discount</dt>
                  <dd>-{formatINR(discount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Shipping</dt>
                <dd>{finalShipping === 0 ? <span className="text-success">Free</span> : formatINR(finalShipping)}</dd>
              </div>
              <div className="flex justify-between border-t pt-2 text-base font-semibold">
                <dt>Total</dt>
                <dd className="font-display">{formatINR(total)}</dd>
              </div>
            </dl>

            <Button type="submit" size="lg" className="mt-5 w-full" disabled={submitting}>
              {submitting ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Placing order…</>
              ) : (
                <>Place order · {formatINR(total)}</>
              )}
            </Button>
          </div>
        </aside>
      </form>
    </div>
  );
}
