import { notFound } from 'next/navigation';
import { ProductDetail } from '@/components/product/product-detail';
import { getProductBySlug, getReviewsForProduct, getRelatedProducts, getCategories } from '@/lib/queries';

export const revalidate = 60;

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug);
  if (!product) notFound();

  const [reviews, related, categories] = await Promise.all([
    getReviewsForProduct(product.id),
    product.category_id ? getRelatedProducts(product.category_id, product.id, 4) : Promise.resolve([]),
    getCategories(),
  ]);

  return (
    <ProductDetail
      product={product}
      reviews={reviews}
      related={related}
      categories={categories}
    />
  );
}
