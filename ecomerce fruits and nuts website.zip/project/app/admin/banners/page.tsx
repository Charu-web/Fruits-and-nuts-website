'use client';

import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import Image from 'next/image';
import { supabase } from '@/lib/supabase';
import type { Banner } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';

const EMPTY = { title: '', subtitle: '', image_url: '', cta_text: '', cta_link: '', sort_order: '0', active: true };

export default function AdminBannersPage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Banner | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('banners').select('*').order('sort_order');
    setBanners((data as Banner[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setForm(EMPTY); setOpen(true); };
  const openEdit = (b: Banner) => {
    setEditing(b);
    setForm({
      title: b.title, subtitle: b.subtitle ?? '', image_url: b.image_url,
      cta_text: b.cta_text ?? '', cta_link: b.cta_link ?? '', sort_order: String(b.sort_order), active: b.active,
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.title.trim() || !form.image_url.trim()) { toast.error('Title and image URL are required'); return; }
    setSaving(true);
    const payload = {
      title: form.title.trim(),
      subtitle: form.subtitle.trim() || null,
      image_url: form.image_url.trim(),
      cta_text: form.cta_text.trim() || null,
      cta_link: form.cta_link.trim() || null,
      sort_order: Number(form.sort_order) || 0,
      active: form.active,
    };
    if (editing) {
      const { error } = await supabase.from('banners').update(payload).eq('id', editing.id);
      if (error) toast.error('Update failed', { description: error.message });
      else toast.success('Banner updated');
    } else {
      const { error } = await supabase.from('banners').insert(payload);
      if (error) toast.error('Create failed', { description: error.message });
      else toast.success('Banner created');
    }
    setSaving(false);
    setOpen(false);
    load();
  };

  const remove = async (b: Banner) => {
    if (!confirm(`Delete banner "${b.title}"?`)) return;
    const { error } = await supabase.from('banners').delete().eq('id', b.id);
    if (error) toast.error('Delete failed');
    else { toast.success('Banner deleted'); load(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Banners</h1>
          <p className="text-sm text-muted-foreground">Homepage carousel slides</p>
        </div>
        <Button onClick={openNew}><Plus className="mr-1.5 h-4 w-4" /> Add banner</Button>
      </div>

      {loading ? (
        <div className="py-16 text-center text-sm text-muted-foreground">Loading…</div>
      ) : banners.length === 0 ? (
        <div className="rounded-xl border border-dashed py-16 text-center text-sm text-muted-foreground">No banners yet.</div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {banners.map((b) => (
            <div key={b.id} className="overflow-hidden rounded-xl border bg-card">
              <div className="relative h-40 bg-secondary">
                <Image src={b.image_url} alt={b.title} fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover" />
                <div className={`absolute right-3 top-3 ${b.active ? 'bg-success' : 'bg-muted'} px-2 py-0.5 rounded-full text-[10px] font-semibold text-background`}>
                  {b.active ? 'Active' : 'Inactive'}
                </div>
              </div>
              <div className="p-4">
                <p className="font-semibold">{b.title}</p>
                {b.subtitle && <p className="mt-0.5 text-xs text-muted-foreground line-clamp-1">{b.subtitle}</p>}
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Order: {b.sort_order}</span>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(b)}><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => remove(b)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit banner' : 'New banner'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4">
            <div>
              <Label htmlFor="b-title">Title *</Label>
              <Input id="b-title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="b-sub">Subtitle</Label>
              <Input id="b-sub" value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="b-img">Image URL *</Label>
              <Input id="b-img" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://…" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="b-cta">CTA text</Label>
                <Input id="b-cta" value={form.cta_text} onChange={(e) => setForm({ ...form, cta_text: e.target.value })} placeholder="Shop now" />
              </div>
              <div>
                <Label htmlFor="b-link">CTA link</Label>
                <Input id="b-link" value={form.cta_link} onChange={(e) => setForm({ ...form, cta_link: e.target.value })} placeholder="/shop" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="b-order">Sort order</Label>
                <Input id="b-order" type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: e.target.value })} />
              </div>
              <div className="flex items-end gap-2 pb-1">
                <Switch id="b-active" checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
                <Label htmlFor="b-active" className="text-sm">Active</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {editing ? 'Save changes' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
