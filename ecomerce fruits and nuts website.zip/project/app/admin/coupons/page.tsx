'use client';

import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatINR } from '@/lib/cart-context';
import type { Coupon } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';

const EMPTY = {
  code: '', type: 'percentage' as Coupon['type'], value: '10', min_order: '0',
  expiry: '', usage_limit: '', active: true,
};

export default function AdminCouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Coupon | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('coupons').select('*').order('created_at', { ascending: false });
    setCoupons((data as Coupon[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setForm(EMPTY); setOpen(true); };
  const openEdit = (c: Coupon) => {
    setEditing(c);
    setForm({
      code: c.code, type: c.type, value: String(c.value), min_order: String(c.min_order),
      expiry: c.expiry ?? '', usage_limit: c.usage_limit ? String(c.usage_limit) : '', active: c.active,
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.code.trim()) { toast.error('Coupon code is required'); return; }
    setSaving(true);
    const payload = {
      code: form.code.trim().toUpperCase(),
      type: form.type,
      value: Number(form.value) || 0,
      min_order: Number(form.min_order) || 0,
      expiry: form.expiry || null,
      usage_limit: form.usage_limit ? Number(form.usage_limit) : null,
      active: form.active,
    };
    if (editing) {
      const { error } = await supabase.from('coupons').update(payload).eq('id', editing.id);
      if (error) toast.error('Update failed', { description: error.message });
      else toast.success('Coupon updated');
    } else {
      const { error } = await supabase.from('coupons').insert(payload);
      if (error) toast.error('Create failed', { description: error.message });
      else toast.success('Coupon created');
    }
    setSaving(false);
    setOpen(false);
    load();
  };

  const remove = async (c: Coupon) => {
    if (!confirm(`Delete coupon "${c.code}"?`)) return;
    const { error } = await supabase.from('coupons').delete().eq('id', c.id);
    if (error) toast.error('Delete failed');
    else { toast.success('Coupon deleted'); load(); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold">Coupons</h1>
          <p className="text-sm text-muted-foreground">{coupons.length} coupons</p>
        </div>
        <Button onClick={openNew}><Plus className="mr-1.5 h-4 w-4" /> Add coupon</Button>
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Value</TableHead>
              <TableHead>Min order</TableHead>
              <TableHead>Usage</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">Loading…</TableCell></TableRow>
            ) : coupons.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">No coupons yet.</TableCell></TableRow>
            ) : coupons.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-mono font-semibold">{c.code}</TableCell>
                <TableCell className="capitalize">{c.type.replace('_', ' ')}</TableCell>
                <TableCell>
                  {c.type === 'percentage' ? `${c.value}%` : c.type === 'flat' ? formatINR(Number(c.value)) : '—'}
                </TableCell>
                <TableCell>{formatINR(Number(c.min_order))}</TableCell>
                <TableCell>{c.used_count}{c.usage_limit ? ` / ${c.usage_limit}` : ''}</TableCell>
                <TableCell><Badge variant={c.active ? 'secondary' : 'outline'}>{c.active ? 'Active' : 'Inactive'}</Badge></TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Pencil className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => remove(c)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit coupon' : 'New coupon'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4">
            <div>
              <Label htmlFor="co-code">Code *</Label>
              <Input id="co-code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="WELCOME10" />
            </div>
            <div>
              <Label htmlFor="co-type">Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as Coupon['type'] })}>
                <SelectTrigger id="co-type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Percentage</SelectItem>
                  <SelectItem value="flat">Flat amount</SelectItem>
                  <SelectItem value="free_shipping">Free shipping</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {form.type !== 'free_shipping' && (
              <div>
                <Label htmlFor="co-value">Value</Label>
                <Input id="co-value" type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="co-min">Min order (₹)</Label>
                <Input id="co-min" type="number" value={form.min_order} onChange={(e) => setForm({ ...form, min_order: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="co-limit">Usage limit</Label>
                <Input id="co-limit" type="number" value={form.usage_limit} onChange={(e) => setForm({ ...form, usage_limit: e.target.value })} placeholder="∞" />
              </div>
            </div>
            <div>
              <Label htmlFor="co-expiry">Expiry date</Label>
              <Input id="co-expiry" type="date" value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })} />
            </div>
            <div className="flex items-center gap-2">
              <Switch id="co-active" checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
              <Label htmlFor="co-active" className="text-sm">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {editing ? 'Save changes' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
