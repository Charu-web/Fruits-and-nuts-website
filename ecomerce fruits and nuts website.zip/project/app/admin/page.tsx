'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { TrendingUp, IndianRupee, ShoppingCart, Users, Package, AlertTriangle, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { formatINR } from '@/lib/cart-context';
import type { Order, Product } from '@/lib/types';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from 'recharts';

interface Stats {
  totalRevenue: number;
  totalOrders: number;
  totalProducts: number;
  lowStock: Product[];
  recentOrders: Order[];
  monthly: { month: string; revenue: number; orders: number }[];
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [ordersRes, productsRes] = await Promise.all([
        supabase.from('orders').select('*').order('created_at', { ascending: false }),
        supabase.from('products').select('*'),
      ]);
      const orders = (ordersRes.data as Order[]) ?? [];
      const products = (productsRes.data as Product[]) ?? [];
      const totalRevenue = orders.reduce((s, o) => s + Number(o.total), 0);
      const lowStock = products.filter((p) => p.stock <= 25).sort((a, b) => a.stock - b.stock).slice(0, 5);

      const monthlyMap = new Map<string, { revenue: number; orders: number }>();
      const now = new Date();
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = d.toLocaleString('en-IN', { month: 'short' });
        monthlyMap.set(key, { revenue: 0, orders: 0 });
      }
      for (const o of orders) {
        const d = new Date(o.created_at);
        const key = d.toLocaleString('en-IN', { month: 'short' });
        if (monthlyMap.has(key)) {
          const cur = monthlyMap.get(key)!;
          cur.revenue += Number(o.total);
          cur.orders += 1;
        }
      }
      const monthly = Array.from(monthlyMap.entries()).map(([month, v]) => ({ month, ...v }));

      setStats({
        totalRevenue,
        totalOrders: orders.length,
        totalProducts: products.length,
        lowStock,
        recentOrders: orders.slice(0, 6),
        monthly,
      });
      setLoading(false);
    })();
  }, []);

  const cards = useMemo(() => {
    if (!stats) return [];
    return [
      { label: 'Total Revenue', value: formatINR(stats.totalRevenue), icon: IndianRupee, tint: 'bg-primary/10 text-primary' },
      { label: 'Total Orders', value: String(stats.totalOrders), icon: ShoppingCart, tint: 'bg-accent/15 text-accent-foreground' },
      { label: 'Products', value: String(stats.totalProducts), icon: Package, tint: 'bg-success/15 text-success' },
      { label: 'Avg Order Value', value: stats.totalOrders ? formatINR(stats.totalRevenue / stats.totalOrders) : '—', icon: TrendingUp, tint: 'bg-warning/15 text-warning-foreground' },
    ];
  }, [stats]);

  if (loading) {
    return <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">Loading dashboard…</div>;
  }
  if (!stats) return null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Welcome back — here&apos;s what&apos;s happening in your store.</p>
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardContent className="flex items-center gap-4 p-5">
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${c.tint}`}>
                <c.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{c.label}</p>
                <p className="font-display text-xl font-semibold">{c.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue &amp; Orders (last 6 months)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.monthly}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Area type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" fill="url(#rev)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Recent orders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Orders</CardTitle>
            <Link href="/admin/orders" className="text-xs text-primary hover:underline">View all</Link>
          </CardHeader>
          <CardContent>
            {stats.recentOrders.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No orders yet.</p>
            ) : (
              <div className="space-y-3">
                {stats.recentOrders.map((o) => (
                  <div key={o.id} className="flex items-center justify-between gap-2 border-b pb-3 last:border-0 last:pb-0">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{o.customer_name}</p>
                      <p className="text-xs text-muted-foreground">{o.order_number} · {new Date(o.created_at).toLocaleDateString('en-IN')}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{formatINR(Number(o.total))}</p>
                      <Badge variant="secondary" className="mt-0.5 capitalize">{o.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Low stock */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-warning" /> Low Stock Alerts</CardTitle>
            <Link href="/admin/products" className="text-xs text-primary hover:underline">Manage</Link>
          </CardHeader>
          <CardContent>
            {stats.lowStock.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">All products well stocked.</p>
            ) : (
              <div className="space-y-3">
                {stats.lowStock.map((p) => (
                  <div key={p.id} className="flex items-center justify-between gap-2 border-b pb-3 last:border-0 last:pb-0">
                    <p className="truncate text-sm font-medium">{p.name}</p>
                    <Badge variant={p.stock === 0 ? 'destructive' : 'secondary'}>
                      {p.stock} left
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
