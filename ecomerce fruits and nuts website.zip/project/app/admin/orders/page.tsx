'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { formatINR } from '@/lib/cart-context';
import type { Order } from '@/lib/types';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const STATUSES = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded'];

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Order | null>(null);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from('orders').select('*').order('created_at', { ascending: false });
    setOrders((data as Order[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from('orders').update({ status }).eq('id', id);
    if (error) toast.error('Update failed');
    else {
      toast.success('Order status updated');
      setOrders((o) => o.map((x) => (x.id === id ? { ...x, status } : x)));
      if (selected?.id === id) setSelected({ ...selected, status });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold">Orders</h1>
        <p className="text-sm text-muted-foreground">{orders.length} total orders</p>
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order #</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">View</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">Loading…</TableCell></TableRow>
            ) : orders.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">No orders yet.</TableCell></TableRow>
            ) : orders.map((o) => (
              <TableRow key={o.id} className="cursor-pointer" onClick={() => setSelected(o)}>
                <TableCell className="font-mono text-xs">{o.order_number}</TableCell>
                <TableCell className="font-medium">{o.customer_name}</TableCell>
                <TableCell className="text-muted-foreground">{new Date(o.created_at).toLocaleDateString('en-IN')}</TableCell>
                <TableCell>{formatINR(Number(o.total))}</TableCell>
                <TableCell><Badge variant="outline" className="uppercase">{o.payment_method}</Badge></TableCell>
                <TableCell>
                  <Select value={o.status} onValueChange={(v) => updateStatus(o.id, v)}>
                    <SelectTrigger className="h-8 w-[130px]" onClick={(e) => e.stopPropagation()}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); setSelected(o); }}>View</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>Order {selected.order_number}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div className="rounded-lg bg-secondary/40 p-4">
                  <p className="font-medium">{selected.customer_name}</p>
                  <p className="text-muted-foreground">{selected.email} · {selected.phone}</p>
                  <p className="mt-1 text-muted-foreground">{selected.address}, {selected.city}, {selected.state ?? ''} {selected.pincode}</p>
                </div>
                <div>
                  <p className="mb-2 font-medium">Items</p>
                  <div className="space-y-2">
                    {Array.isArray(selected.items) && selected.items.map((it: any, i: number) => (
                      <div key={i} className="flex justify-between border-b pb-2 last:border-0">
                        <span>{it.quantity} × {it.name}</span>
                        <span>{formatINR(Number(it.price) * it.quantity)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <dl className="space-y-1.5 border-t pt-3">
                  <div className="flex justify-between"><dt className="text-muted-foreground">Subtotal</dt><dd>{formatINR(Number(selected.subtotal))}</dd></div>
                  {Number(selected.discount) > 0 && <div className="flex justify-between text-success"><dt>Discount</dt><dd>-{formatINR(Number(selected.discount))}</dd></div>}
                  <div className="flex justify-between"><dt className="text-muted-foreground">Shipping</dt><dd>{Number(selected.shipping) === 0 ? 'Free' : formatINR(Number(selected.shipping))}</dd></div>
                  <div className="flex justify-between text-base font-semibold"><dt>Total</dt><dd className="font-display">{formatINR(Number(selected.total))}</dd></div>
                </dl>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Status:</span>
                  <Badge variant="secondary" className="capitalize">{selected.status}</Badge>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
