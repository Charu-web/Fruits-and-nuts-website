'use client';

import { useEffect, useState } from 'react';
import { Check, X, Star } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Review } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ReviewWithProduct extends Review {
  product_name?: string;
}

export default function AdminReviewsPage() {
  const [reviews, setReviews] = useState<ReviewWithProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'pending' | 'approved' | 'all'>('pending');

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('reviews')
      .select('*, products(name)')
      .order('created_at', { ascending: false });
    const mapped = (data ?? []).map((r: any) => ({ ...r, product_name: r.products?.name ?? '—' })) as ReviewWithProduct[];
    setReviews(mapped);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const setApproved = async (r: ReviewWithProduct, approved: boolean) => {
    const { error } = await supabase.from('reviews').update({ approved }).eq('id', r.id);
    if (error) toast.error('Update failed');
    else {
      toast.success(approved ? 'Review approved' : 'Review hidden');
      setReviews((rs) => rs.map((x) => (x.id === r.id ? { ...x, approved } : x)));
    }
  };

  const remove = async (r: ReviewWithProduct) => {
    if (!confirm('Delete this review permanently?')) return;
    const { error } = await supabase.from('reviews').delete().eq('id', r.id);
    if (error) toast.error('Delete failed');
    else { toast.success('Review deleted'); setReviews((rs) => rs.filter((x) => x.id !== r.id)); }
  };

  const visible = reviews.filter((r) =>
    filter === 'all' ? true : filter === 'approved' ? r.approved : !r.approved
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Reviews</h1>
          <p className="text-sm text-muted-foreground">Moderate customer reviews</p>
        </div>
        <div className="flex gap-1 rounded-lg border bg-card p-1">
          {(['pending', 'approved', 'all'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'rounded-md px-3 py-1.5 text-xs font-medium capitalize transition',
                filter === f ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>Reviewer</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Comment</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={6} className="py-10 text-center text-sm text-muted-foreground">Loading…</TableCell></TableRow>
            ) : visible.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="py-10 text-center text-sm text-muted-foreground">No reviews to show.</TableCell></TableRow>
            ) : visible.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-medium">{r.product_name}</TableCell>
                <TableCell>{r.name}</TableCell>
                <TableCell>
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={cn('h-3.5 w-3.5', i < r.rating ? 'fill-accent text-accent' : 'text-muted-foreground/30')} />
                    ))}
                  </div>
                </TableCell>
                <TableCell className="max-w-xs">
                  {r.title && <p className="font-medium">{r.title}</p>}
                  {r.body && <p className="line-clamp-2 text-xs text-muted-foreground">{r.body}</p>}
                </TableCell>
                <TableCell>
                  <Badge variant={r.approved ? 'secondary' : 'outline'}>
                    {r.approved ? 'Approved' : 'Pending'}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  {!r.approved ? (
                    <Button variant="ghost" size="icon" onClick={() => setApproved(r, true)} aria-label="Approve">
                      <Check className="h-4 w-4 text-success" />
                    </Button>
                  ) : (
                    <Button variant="ghost" size="icon" onClick={() => setApproved(r, false)} aria-label="Hide">
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => remove(r)} aria-label="Delete">
                    <X className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
