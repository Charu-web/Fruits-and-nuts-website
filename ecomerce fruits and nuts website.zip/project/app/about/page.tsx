import Image from 'next/image';
import { Leaf, Heart, Award, Truck } from 'lucide-react';

export const metadata = { title: 'About — Fruits & Nuts' };

const VALUES = [
  { icon: Leaf, title: 'Naturally Sourced', desc: 'We partner directly with growers to bring you the freshest, most natural products.' },
  { icon: Heart, title: 'Crafted with Care', desc: 'Every chocolate and hamper is handcrafted in small batches by master artisans.' },
  { icon: Award, title: 'Premium Quality', desc: 'Only the top 5% of produce makes it into our packaging — quality you can taste.' },
  { icon: Truck, title: 'Fast & Fresh', desc: 'Cold-chain logistics ensure your treats arrive fresh, anywhere in India.' },
];

export default function AboutPage() {
  return (
    <div>
      <section className="relative h-[40vh] min-h-[300px] w-full overflow-hidden">
        <Image
          src="https://images.pexels.com/photos/4226806/pexels-photo-4226806.jpeg?auto=compress&cs=tinysrgb&w=1600"
          alt="Our story"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-foreground/50" />
        <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-center px-6 text-background">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-background/80">Our story</p>
          <h1 className="mt-2 font-display text-4xl font-semibold sm:text-5xl">Crafting joy since 2015</h1>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <p className="text-lg leading-relaxed text-foreground/85">
          Fruits &amp; Nuts began as a small family kitchen with a simple belief: that the finest chocolates, dry fruits and nuts should be accessible to everyone — beautifully packaged, freshly made, and delivered with care.
        </p>
        <p className="mt-4 leading-relaxed text-muted-foreground">
          A decade later, we&apos;ve grown into one of India&apos;s most loved premium treat brands, but our promise hasn&apos;t changed. We still hand-pick every nut, hand-roll every truffle, and hand-pack every hamper. From our family to yours, we hope you taste the difference.
        </p>
      </section>

      <section className="bg-secondary/40 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map((v) => (
              <div key={v.title} className="rounded-2xl border bg-card p-6 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <v.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold">{v.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
