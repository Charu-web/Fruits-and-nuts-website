'use client';

import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function ContactPage() {
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Message sent!', { description: 'We will get back to you within 24 hours.' });
    (e.target as HTMLFormElement).reset();
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Contact</p>
        <h1 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">Get in touch</h1>
        <p className="mx-auto mt-2 max-w-lg text-sm text-muted-foreground">
          Questions about an order, a bulk enquiry, or just want to say hello? We&apos;d love to hear from you.
        </p>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          {[
            { icon: Mail, label: 'Email', value: 'hello@fruitsandnuts.example' },
            { icon: Phone, label: 'Phone', value: '+91 98765 43210' },
            { icon: MapPin, label: 'Address', value: '123 Craft Lane, Mumbai 400001, India' },
            { icon: Clock, label: 'Hours', value: 'Mon–Sat, 9 AM – 7 PM IST' },
          ].map((c) => (
            <div key={c.label} className="flex items-start gap-4 rounded-xl border bg-card p-5">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                <c.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</p>
                <p className="mt-0.5 text-sm font-medium">{c.value}</p>
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={onSubmit} className="rounded-xl border bg-card p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="c-name">Name</Label>
              <Input id="c-name" required className="mt-1" />
            </div>
            <div>
              <Label htmlFor="c-email">Email</Label>
              <Input id="c-email" type="email" required className="mt-1" />
            </div>
          </div>
          <div className="mt-4">
            <Label htmlFor="c-subject">Subject</Label>
            <Input id="c-subject" required className="mt-1" />
          </div>
          <div className="mt-4">
            <Label htmlFor="c-msg">Message</Label>
            <Textarea id="c-msg" required rows={5} className="mt-1" />
          </div>
          <Button type="submit" className="mt-5 w-full">Send message</Button>
        </form>
      </div>
    </div>
  );
}
