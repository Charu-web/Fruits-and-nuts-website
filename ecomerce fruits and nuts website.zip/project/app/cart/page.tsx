'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart, formatINR } from '@/lib/cart-context';
import { toast } from 'sonner';

export default function CartPage() {
  const { items, subtotal, setQty, remove, count } = useCart();

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center justify-center px-4 py-24 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-secondary">
          <ShoppingBag className="h-9 w-9 text-muted-foreground" />
        </div>
        <h1 className="mt-6 font-display text-2xl font-semibold">Your cart is empty</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Looks like you haven&apos;t added anything yet. Let&apos;s fix that.
        </p>
        <Button asChild className="mt-6">
          <Link href="/shop">Start shopping <ArrowRight className="ml-2 h-4 w-4" /></Link>
        </Button>
      </div>
    );
  }

  const shipping = subtotal >= 999 ? 0 : 79;
  const total = subtotal + shipping;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="font-display text-3xl font-semibold sm:text-4xl">Shopping Cart</h1>
      <p className="mt-1 text-sm text-muted-foreground">{count} {count === 1 ? 'item' : 'items'} in your cart</p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        {/* Items */}
        <div className="space-y-4">
          {items.map(({ product, quantity }) => (
            <div key={product.id} className="flex gap-4 rounded-xl border bg-card p-4">
              <Link href={`/product/${product.slug}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-lg bg-secondary">
                <Image src={product.image_url} alt={product.name} fill sizes="96px" className="object-cover" />
              </Link>
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <Link href={`/product/${product.slug}`} className="text-sm font-semibold hover:text-primary">
                      {product.name}
                    </Link>
                    <p className="mt-0.5 text-xs text-muted-foreground">per {product.unit}</p>
                  </div>
                  <button
                    onClick={() => { remove(product.id); toast.success('Removed from cart'); }}
                    className="text-muted-foreground hover:text-destructive"
                    aria-label="Remove"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-auto flex items-end justify-between pt-3">
                  <div className="flex items-center rounded-lg border">
                    <button
                      onClick={() => setQty(product.id, quantity - 1)}
                      className="flex h-8 w-8 items-center justify-center text-muted-foreground hover:text-foreground"
                      aria-label="Decrease"
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm font-medium">{quantity}</span>
                    <button
                      onClick={() => setQty(product.id, quantity + 1)}
                      className="flex h-8 w-8 items-center justify-center text-muted-foreground hover:text-foreground"
                      aria-label="Increase"
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatINR(Number(product.price) * quantity)}</p>
                    <p className="text-xs text-muted-foreground">{formatINR(Number(product.price))} each</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <Button asChild variant="outline">
            <Link href="/shop">Continue shopping</Link>
          </Button>
        </div>

        {/* Summary */}
        <aside className="lg:sticky lg:top-28 lg:self-start">
          <div className="rounded-xl border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Order Summary</h2>
            <dl className="mt-4 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd className="font-medium">{formatINR(subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Shipping</dt>
                <dd className="font-medium">{shipping === 0 ? <span className="text-success">Free</span> : formatINR(shipping)}</dd>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-muted-foreground">
                  Add {formatINR(999 - subtotal)} more to unlock free shipping.
                </p>
              )}
              <div className="border-t pt-2.5" />
              <div className="flex justify-between text-base">
                <dt className="font-semibold">Total</dt>
                <dd className="font-display font-semibold">{formatINR(total)}</dd>
              </div>
            </dl>

            <div className="mt-4 rounded-lg bg-secondary/60 p-3 text-xs text-muted-foreground">
              <p className="flex items-center gap-1.5"><Tag className="h-3.5 w-3.5" /> Have a coupon? Apply it at checkout.</p>
            </div>

            <Button asChild size="lg" className="mt-4 w-full">
              <Link href="/checkout">Proceed to checkout <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <p className="mt-3 text-center text-xs text-muted-foreground">Secure checkout · Razorpay &amp; Stripe</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
