import { ShopClient } from '@/components/shop/shop-client';
import { getCategories, getAllProducts } from '@/lib/queries';

export const revalidate = 60;

export default async function ShopPage({
  searchParams,
}: {
  searchParams: { category?: string; q?: string };
}) {
  const [categories, products] = await Promise.all([getCategories(), getAllProducts()]);

  return (
    <ShopClient
      categories={categories}
      products={products}
      initialCategory={searchParams?.category ?? 'all'}
      initialQuery={searchParams?.q ?? ''}
    />
  );
}
