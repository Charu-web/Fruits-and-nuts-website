'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, Package, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { formatINR } from '@/lib/cart-context';
import type { Order } from '@/lib/types';

export default function OrderSuccessPage() {
  const params = useSearchParams();
  const orderNumber = params.get('o');
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderNumber) return;
    (async () => {
      const { data } = await supabase
        .from('orders')
        .select('*')
        .eq('order_number', orderNumber)
        .maybeSingle();
      setOrder((data as Order) ?? null);
      setLoading(false);
    })();
  }, [orderNumber]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-16 text-center sm:px-6">
      <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-success/15 text-success">
        <CheckCircle2 className="h-10 w-10" />
      </div>
      <h1 className="mt-6 font-display text-3xl font-semibold">Order confirmed!</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Thank you for your purchase. We&apos;ve received your order and will send a confirmation email shortly.
      </p>

      {orderNumber && (
        <p className="mt-4 text-sm">
          Order number: <span className="font-mono font-semibold text-primary">{orderNumber}</span>
        </p>
      )}

      {loading ? (
        <p className="mt-6 text-sm text-muted-foreground">Loading order details…</p>
      ) : order ? (
        <div className="mt-8 rounded-xl border bg-card p-6 text-left">
          <div className="flex items-center gap-2 text-sm font-semibold">
            <Package className="h-4 w-4" /> Order Summary
          </div>
          <div className="mt-4 space-y-3">
            {Array.isArray(order.items) && order.items.map((it: any, i: number) => (
              <div key={i} className="flex justify-between text-sm">
                <span className="text-muted-foreground">{it.quantity} × {it.name}</span>
                <span>{formatINR(Number(it.price) * it.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between border-t pt-3 text-base font-semibold">
            <span>Total</span>
            <span className="font-display">{formatINR(Number(order.total))}</span>
          </div>
          <div className="mt-4 rounded-lg bg-secondary/50 p-3 text-xs text-muted-foreground">
            <p><span className="font-medium text-foreground">Shipping to:</span> {order.address}, {order.city}, {order.state ?? ''} {order.pincode}</p>
            <p className="mt-1"><span className="font-medium text-foreground">Payment:</span> {order.payment_method.toUpperCase()}</p>
          </div>
        </div>
      ) : null}

      <div className="mt-8 flex justify-center gap-3">
        <Button asChild>
          <Link href="/shop">Continue shopping <ArrowRight className="ml-2 h-4 w-4" /></Link>
        </Button>
        <Button asChild variant="outline">
          <Link href="/">Back to home</Link>
        </Button>
      </div>
    </div>
  );
}
