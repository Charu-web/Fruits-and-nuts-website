import { HeroCarousel } from '@/components/home/hero-carousel';
import { FeatureStrip } from '@/components/home/feature-strip';
import { CategoryGrid } from '@/components/home/category-grid';
import { ProductRow } from '@/components/home/product-row';
import { PromoBanner } from '@/components/home/promo-banner';
import { Testimonials } from '@/components/home/testimonials';
import { Faq } from '@/components/home/faq';
import { getBanners, getCategories, getFeaturedProducts, getBestsellers, getNewArrivals } from '@/lib/queries';

export const revalidate = 60;

export default async function Home() {
  const [banners, categories, featured, bestsellers, newArrivals] = await Promise.all([
    getBanners(),
    getCategories(),
    getFeaturedProducts(4),
    getBestsellers(4),
    getNewArrivals(4),
  ]);

  return (
    <>
      <HeroCarousel banners={banners} />
      <FeatureStrip />
      <CategoryGrid categories={categories} />
      <ProductRow eyebrow="Handpicked" title="Featured Products" products={featured} />
      <PromoBanner />
      <ProductRow eyebrow="Trending now" title="Best Sellers" products={bestsellers} />
      <ProductRow eyebrow="Just landed" title="New Arrivals" products={newArrivals} />
      <Testimonials />
      <Faq />
    </>
  );
}
