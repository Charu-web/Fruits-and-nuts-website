import './globals.css';
import type { Metadata } from 'next';
import { Inter, Fraunces } from 'next/font/google';
import { ThemeProvider } from '@/components/theme-provider';
import { CartProvider } from '@/lib/cart-context';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';
import { Toaster } from 'sonner';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const fraunces = Fraunces({ subsets: ['latin'], variable: '--font-fraunces' });

export const metadata: Metadata = {
  title: 'Fruits & Nuts — Premium Chocolates, Dry Fruits & Gift Hampers',
  description:
    'Shop premium chocolates, dry fruits, nuts, gift hampers and healthy snacks. Handcrafted treats delivered fresh across India.',
  keywords: [
    'premium chocolates',
    'dry fruits',
    'nuts',
    'gift hampers',
    'healthy snacks',
    'online store',
  ],
  openGraph: {
    title: 'Fruits & Nuts — Premium Chocolates, Dry Fruits & Gift Hampers',
    description:
      'Handcrafted chocolates, premium dry fruits, nuts and gift hampers delivered fresh.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Fruits & Nuts',
    description: 'Premium chocolates, dry fruits, nuts and gift hampers.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${fraunces.variable} font-sans antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <CartProvider>
            <div className="flex min-h-screen flex-col">
              <SiteHeader />
              <main className="flex-1">{children}</main>
              <SiteFooter />
            </div>
            <Toaster position="bottom-right" richColors closeButton />
          </CartProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
