'use client';

import Link from 'next/link';
import { Leaf, Mail, Phone, MapPin, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const FOOTER_LINKS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: 'Shop',
    links: [
      { label: 'All Products', href: '/shop' },
      { label: 'Chocolates', href: '/shop?category=premium-chocolates' },
      { label: 'Dry Fruits', href: '/shop?category=dry-fruits' },
      { label: 'Gift Hampers', href: '/shop?category=gift-hampers' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About Us', href: '/about' },
      { label: 'Contact', href: '/contact' },
      { label: 'Admin', href: '/admin' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Shipping & Returns', href: '/contact' },
      { label: 'Track Order', href: '/contact' },
      { label: 'FAQs', href: '/#faq' },
    ],
  },
];

export function SiteFooter() {
  const onSubscribe = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = new FormData(form).get('email') as string;
    if (email) {
      toast.success('Subscribed!', { description: 'You are now on the Fruits & Nuts mailing list.' });
      form.reset();
    }
  };

  return (
    <footer className="border-t bg-secondary/40">
      {/* Newsletter */}
      <section className="border-b">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
          <div className="grid gap-8 md:grid-cols-2 md:items-center">
            <div>
              <h3 className="font-display text-2xl font-semibold">Join the Fruits &amp; Nuts family</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Get 10% off your first order, plus exclusive deals and early access to new launches.
              </p>
            </div>
            <form onSubmit={onSubscribe} className="flex w-full max-w-md gap-2 md:ml-auto">
              <Input
                type="email"
                name="email"
                required
                placeholder="Enter your email"
                className="bg-background"
              />
              <Button type="submit">Subscribe</Button>
            </form>
          </div>
        </div>
      </section>

      {/* Main footer */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <Leaf className="h-5 w-5" />
              </div>
              <span className="font-display text-lg font-semibold">Fruits &amp; Nuts</span>
            </Link>
            <p className="mt-4 max-w-sm text-sm text-muted-foreground">
              Premium chocolates, dry fruits, nuts and gift hampers — handcrafted with care and delivered fresh across India.
            </p>
            <div className="mt-5 space-y-2 text-sm text-muted-foreground">
              <p className="flex items-center gap-2"><Mail className="h-4 w-4" /> hello@fruitsandnuts.example</p>
              <p className="flex items-center gap-2"><Phone className="h-4 w-4" /> +91 98765 43210</p>
              <p className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Mumbai, India</p>
            </div>
            <div className="mt-5 flex gap-2">
              {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="social"
                  className="flex h-9 w-9 items-center justify-center rounded-full border bg-background text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {FOOTER_LINKS.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold uppercase tracking-wider">{col.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-sm text-muted-foreground transition-colors hover:text-primary">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} Fruits &amp; Nuts. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
