'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Star, ShoppingBag, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart, formatINR } from '@/lib/cart-context';
import type { Product } from '@/lib/types';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const discount = product.compare_price
    ? Math.round(((product.compare_price - product.price) / product.compare_price) * 100)
    : 0;

  const onAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    add(product, 1);
    toast.success('Added to cart', { description: product.name });
  };

  return (
    <Link
      href={`/product/${product.slug}`}
      className="group relative flex flex-col overflow-hidden rounded-xl border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative aspect-square overflow-hidden bg-secondary">
        <Image
          src={product.image_url}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.badge && (
            <Badge className="bg-primary text-primary-foreground shadow-sm">{product.badge}</Badge>
          )}
          {discount > 0 && (
            <Badge className="bg-accent text-accent-foreground shadow-sm">-{discount}%</Badge>
          )}
        </div>
        <button
          aria-label="Add to wishlist"
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-background/80 text-foreground opacity-0 backdrop-blur transition-all duration-300 hover:text-primary group-hover:opacity-100"
          onClick={(e) => { e.preventDefault(); toast.success('Saved to wishlist'); }}
        >
          <Heart className="h-4 w-4" />
        </button>
        {product.stock === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/60">
            <span className="rounded-full bg-foreground px-4 py-1.5 text-xs font-semibold text-background">Out of stock</span>
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="h-3.5 w-3.5 fill-accent text-accent" />
          <span className="font-medium text-foreground">{product.rating.toFixed(1)}</span>
          <span>· {product.reviews_count} reviews</span>
        </div>
        <h3 className="mt-1.5 line-clamp-2 text-sm font-semibold leading-snug group-hover:text-primary">
          {product.name}
        </h3>
        <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{product.description}</p>

        <div className="mt-3 flex items-end justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="font-display text-lg font-semibold">{formatINR(Number(product.price))}</span>
              {product.compare_price && (
                <span className="text-xs text-muted-foreground line-through">{formatINR(Number(product.compare_price))}</span>
              )}
            </div>
            <span className="text-[11px] text-muted-foreground">per {product.unit}</span>
          </div>
          <Button
            size="icon"
            className={cn('h-9 w-9 shrink-0')}
            onClick={onAdd}
            disabled={product.stock === 0}
            aria-label="Add to cart"
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Link>
  );
}
