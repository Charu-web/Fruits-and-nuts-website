'use client';

import { useEffect, useState, useCallback } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Banner } from '@/lib/types';
import { cn } from '@/lib/utils';

export function HeroCarousel({ banners }: { banners: Banner[] }) {
  const [index, setIndex] = useState(0);
  const count = banners.length;

  const next = useCallback(() => setIndex((i) => (i + 1) % count), [count]);
  const prev = useCallback(() => setIndex((i) => (i - 1 + count) % count), [count]);

  useEffect(() => {
    if (count <= 1) return;
    const t = setInterval(next, 6000);
    return () => clearInterval(t);
  }, [next, count]);

  if (count === 0) return null;

  return (
    <section className="relative w-full overflow-hidden bg-secondary">
      <div className="relative h-[60vh] min-h-[420px] w-full sm:h-[70vh]">
        {banners.map((b, i) => (
          <div
            key={b.id}
            className={cn(
              'absolute inset-0 transition-opacity duration-700',
              i === index ? 'opacity-100' : 'opacity-0 pointer-events-none'
            )}
          >
            <Image
              src={b.image_url}
              alt={b.title}
              fill
              priority={i === 0}
              sizes="100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-foreground/70 via-foreground/40 to-transparent" />
            <div className="relative z-10 mx-auto flex h-full max-w-7xl items-center px-6 sm:px-10">
              <div className="max-w-xl text-background">
                <h2 className="font-display text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
                  {b.title}
                </h2>
                {b.subtitle && (
                  <p className="mt-4 text-base text-background/85 sm:text-lg">{b.subtitle}</p>
                )}
                {b.cta_text && b.cta_link && (
                  <Button asChild size="lg" className="mt-7">
                    <Link href={b.cta_link}>{b.cta_text}</Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {count > 1 && (
        <>
          <button
            aria-label="Previous"
            onClick={prev}
            className="absolute left-3 top-1/2 z-20 hidden -translate-y-1/2 items-center justify-center rounded-full bg-background/30 p-2 text-background backdrop-blur transition hover:bg-background/50 sm:flex"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            aria-label="Next"
            onClick={next}
            className="absolute right-3 top-1/2 z-20 hidden -translate-y-1/2 items-center justify-center rounded-full bg-background/30 p-2 text-background backdrop-blur transition hover:bg-background/50 sm:flex"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
          <div className="absolute bottom-4 left-1/2 z-20 flex -translate-x-1/2 gap-2">
            {banners.map((_, i) => (
              <button
                key={i}
                aria-label={`Slide ${i + 1}`}
                onClick={() => setIndex(i)}
                className={cn(
                  'h-2 rounded-full transition-all',
                  i === index ? 'w-7 bg-background' : 'w-2 bg-background/50'
                )}
              />
            ))}
          </div>
        </>
      )}
    </section>
  );
}
