'use client';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const FAQS = [
  { q: 'How long does delivery take?', a: 'Orders are dispatched within 24 hours and typically delivered within 3–5 business days across India. Metro cities often receive next-day delivery.' },
  { q: 'Are your products fresh?', a: 'Yes. All chocolates and dry fruits are packed in small batches with best-before dates clearly printed. We never ship expired or near-expiry stock.' },
  { q: 'Do you offer gift wrapping?', a: 'Our gift hampers come in premium keepsake packaging by default. For other products, you can add a gift wrap option at checkout for a small fee.' },
  { q: 'What payment methods do you accept?', a: 'We accept UPI, all major credit/debit cards, net banking, and popular wallets via Razorpay and Stripe. Cash on delivery is available on select pin codes.' },
  { q: 'What is your return policy?', a: 'Due to the perishable nature of our products, we accept returns only for damaged or incorrect items. Report within 48 hours of delivery with photos and we will replace or refund.' },
  { q: 'Do you ship internationally?', a: 'Currently we ship only within India. International shipping is coming soon — subscribe to our newsletter to be notified.' },
];

export function Faq() {
  return (
    <section id="faq" className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Help center</p>
        <h2 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">Frequently asked questions</h2>
      </div>
      <Accordion type="single" collapsible className="w-full">
        {FAQS.map((item, i) => (
          <AccordionItem key={i} value={`item-${i}`}>
            <AccordionTrigger className="text-left text-base font-medium">
              {item.q}
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              {item.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}
