import Link from 'next/link';
import { ProductCard } from '@/components/product-card';
import type { Product } from '@/lib/types';

interface Props {
  title: string;
  eyebrow?: string;
  products: Product[];
  viewAllHref?: string;
}

export function ProductRow({ title, eyebrow, products, viewAllHref = '/shop' }: Props) {
  if (products.length === 0) return null;
  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <div className="mb-8 flex items-end justify-between">
        <div>
          {eyebrow && (
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{eyebrow}</p>
          )}
          <h2 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">{title}</h2>
        </div>
        <Link href={viewAllHref} className="hidden text-sm font-medium text-primary hover:underline sm:inline">
          View all →
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
