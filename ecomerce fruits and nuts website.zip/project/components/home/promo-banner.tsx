import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';

export function PromoBanner() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="relative overflow-hidden rounded-2xl bg-primary text-primary-foreground">
        <div className="grid items-center gap-6 p-8 sm:p-12 md:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground/80">Limited time</p>
            <h2 className="mt-2 font-display text-3xl font-semibold leading-tight sm:text-4xl">
              Festive Sale — up to 30% off
            </h2>
            <p className="mt-3 max-w-md text-primary-foreground/85">
              Stock up on premium chocolates, dry fruits and gift hampers for the festive season. Use code <span className="font-semibold">FESTIVE30</span> at checkout.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild size="lg" variant="secondary">
                <Link href="/shop">Shop the sale</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground">
                <Link href="/shop?category=gift-hampers">Gift hampers</Link>
              </Button>
            </div>
          </div>
          <div className="relative h-56 sm:h-72">
            <Image
              src="https://images.pexels.com/photos/264787/pexels-photo-264787.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Festive hampers"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="rounded-xl object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
