import Image from 'next/image';
import { Star } from 'lucide-react';

const TESTIMONIALS = [
  {
    name: 'Ananya Iyer',
    role: 'Verified Buyer',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=200',
    quote: 'The Belgian chocolate assortment is the best I have ever tasted. Packaging is gorgeous and delivery was lightning fast.',
    rating: 5,
  },
  {
    name: 'Karan Mehta',
    role: 'Corporate Client',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200',
    quote: 'Ordered 50 corporate hampers for our team. Every single one arrived perfectly packed. The quality is unmatched.',
    rating: 5,
  },
  {
    name: 'Riya Desai',
    role: 'Verified Buyer',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=200',
    quote: 'The Medjool dates are incredibly soft and sweet. My whole family is hooked. Will be ordering again for Diwali.',
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section className="bg-secondary/40 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mb-10 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Loved by customers</p>
          <h2 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">What our customers say</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure
              key={t.name}
              className="flex flex-col rounded-2xl border bg-card p-6 shadow-sm"
            >
              <div className="flex gap-1">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-foreground/85">
                “{t.quote}”
              </blockquote>
              <figcaption className="mt-5 flex items-center gap-3">
                <div className="relative h-10 w-10 overflow-hidden rounded-full">
                  <Image src={t.avatar} alt={t.name} fill sizes="40px" className="object-cover" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
