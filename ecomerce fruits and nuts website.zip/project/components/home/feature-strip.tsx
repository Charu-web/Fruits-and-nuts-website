import { Truck, ShieldCheck, Leaf, Gift } from 'lucide-react';

const FEATURES = [
  { icon: Truck, title: 'Free Shipping', desc: 'On orders above ₹999' },
  { icon: ShieldCheck, title: 'Secure Payments', desc: 'Razorpay & Stripe' },
  { icon: Leaf, title: '100% Natural', desc: 'No preservatives' },
  { icon: Gift, title: 'Premium Gift Boxes', desc: 'Perfect for any occasion' },
];

export function FeatureStrip() {
  return (
    <section className="border-y bg-secondary/40">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-8 sm:px-6 lg:grid-cols-4">
        {FEATURES.map((f) => (
          <div key={f.title} className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
              <f.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">{f.title}</p>
              <p className="text-xs text-muted-foreground">{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
