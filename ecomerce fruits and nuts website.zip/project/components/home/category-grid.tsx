import Image from 'next/image';
import Link from 'next/link';
import type { Category } from '@/lib/types';

export function CategoryGrid({ categories }: { categories: Category[] }) {
  if (categories.length === 0) return null;
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="mb-8 flex items-end justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Explore</p>
          <h2 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">Shop by Category</h2>
        </div>
        <Link href="/shop" className="hidden text-sm font-medium text-primary hover:underline sm:inline">
          View all →
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/shop?category=${c.slug}`}
            className="group relative aspect-[4/5] overflow-hidden rounded-xl"
          >
            {c.image_url && (
              <Image
                src={c.image_url}
                alt={c.name}
                fill
                sizes="(max-width: 640px) 50vw, 20vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-4">
              <h3 className="font-display text-lg font-semibold text-background">{c.name}</h3>
              <p className="mt-0.5 text-xs text-background/80 line-clamp-1">{c.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
