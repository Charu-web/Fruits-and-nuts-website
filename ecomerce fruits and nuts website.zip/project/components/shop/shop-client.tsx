'use client';

import { useMemo, useState } from 'react';
import { ProductCard } from '@/components/product-card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { SlidersHorizontal, Search, X } from 'lucide-react';
import type { Category, Product } from '@/lib/types';
import { formatINR } from '@/lib/cart-context';
import { cn } from '@/lib/utils';

type SortKey = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';

interface Props {
  categories: Category[];
  products: Product[];
  initialCategory: string;
  initialQuery: string;
}

const PRICE_BUCKETS = [
  { label: 'Under ₹500', min: 0, max: 500 },
  { label: '₹500 – ₹1000', min: 500, max: 1000 },
  { label: '₹1000 – ₹2000', min: 1000, max: 2000 },
  { label: 'Above ₹2000', min: 2000, max: 100000 },
];

export function ShopClient({ categories, products, initialCategory, initialQuery }: Props) {
  const [category, setCategory] = useState<string>(initialCategory);
  const [query, setQuery] = useState(initialQuery);
  const [priceBucket, setPriceBucket] = useState<number | null>(null);
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [sort, setSort] = useState<SortKey>('featured');

  const filtered = useMemo(() => {
    let list = [...products];
    if (category !== 'all') {
      const cat = categories.find((c) => c.slug === category);
      if (cat) list = list.filter((p) => p.category_id === cat.id);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.description ?? '').toLowerCase().includes(q)
      );
    }
    if (priceBucket !== null) {
      const b = PRICE_BUCKETS[priceBucket];
      list = list.filter((p) => Number(p.price) >= b.min && Number(p.price) <= b.max);
    }
    if (onlyInStock) list = list.filter((p) => p.stock > 0);

    switch (sort) {
      case 'price-asc':
        list.sort((a, b) => Number(a.price) - Number(b.price));
        break;
      case 'price-desc':
        list.sort((a, b) => Number(b.price) - Number(a.price));
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        list.sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
        break;
      default:
        list.sort((a, b) => a.sort_order - b.sort_order);
    }
    return list;
  }, [products, categories, category, query, priceBucket, onlyInStock, sort]);

  const activeCatName = category === 'all' ? 'All Products' : categories.find((c) => c.slug === category)?.name ?? 'All Products';

  const FiltersBody = (
    <div className="space-y-6">
      <div>
        <h4 className="mb-3 text-sm font-semibold uppercase tracking-wider">Categories</h4>
        <div className="space-y-2">
          <CategoryButton label="All Products" active={category === 'all'} onClick={() => setCategory('all')} count={products.length} />
          {categories.map((c) => (
            <CategoryButton
              key={c.id}
              label={c.name}
              active={category === c.slug}
              onClick={() => setCategory(c.slug)}
              count={products.filter((p) => p.category_id === c.id).length}
            />
          ))}
        </div>
      </div>

      <div>
        <h4 className="mb-3 text-sm font-semibold uppercase tracking-wider">Price</h4>
        <div className="space-y-2">
          {PRICE_BUCKETS.map((b, i) => (
            <label key={b.label} className="flex cursor-pointer items-center gap-2.5 text-sm">
              <Checkbox
                checked={priceBucket === i}
                onCheckedChange={(v) => setPriceBucket(v ? i : null)}
              />
              {b.label}
            </label>
          ))}
        </div>
      </div>

      <div>
        <h4 className="mb-3 text-sm font-semibold uppercase tracking-wider">Availability</h4>
        <label className="flex cursor-pointer items-center gap-2.5 text-sm">
          <Checkbox checked={onlyInStock} onCheckedChange={(v) => setOnlyInStock(!!v)} />
          In stock only
        </label>
      </div>
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      {/* Header */}
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Shop</p>
        <h1 className="mt-1 font-display text-3xl font-semibold sm:text-4xl">{activeCatName}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {filtered.length} {filtered.length === 1 ? 'product' : 'products'} found
        </p>
      </div>

      {/* Search + sort bar */}
      <div className="mb-6 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products…"
            className="pl-9"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="featured">Featured</SelectItem>
            <SelectItem value="price-asc">Price: Low to High</SelectItem>
            <SelectItem value="price-desc">Price: High to Low</SelectItem>
            <SelectItem value="rating">Top Rated</SelectItem>
            <SelectItem value="newest">Newest</SelectItem>
          </SelectContent>
        </Select>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" className="lg:hidden">
              <SlidersHorizontal className="mr-2 h-4 w-4" /> Filters
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
            </SheetHeader>
            <div className="px-1 pb-6 pt-4">{FiltersBody}</div>
          </SheetContent>
        </Sheet>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        {/* Desktop sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-28">{FiltersBody}</div>
        </aside>

        {/* Grid */}
        <div>
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-xl border border-dashed py-24 text-center">
              <p className="text-lg font-medium">No products found</p>
              <p className="mt-1 text-sm text-muted-foreground">Try adjusting your filters or search.</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setCategory('all');
                  setQuery('');
                  setPriceBucket(null);
                  setOnlyInStock(false);
                }}
              >
                Clear filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CategoryButton({
  label,
  active,
  onClick,
  count,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  count: number;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-sm transition-colors',
        active ? 'bg-primary/10 font-medium text-primary' : 'hover:bg-secondary'
      )}
    >
      <span>{label}</span>
      <span className={cn('text-xs', active ? 'text-primary/70' : 'text-muted-foreground')}>{count}</span>
    </button>
  );
}
