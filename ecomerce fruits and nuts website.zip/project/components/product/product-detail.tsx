'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { Star, ShoppingBag, Minus, Plus, Truck, ShieldCheck, RefreshCw, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ProductCard } from '@/components/product-card';
import { ReviewForm } from '@/components/product/review-form';
import { useCart, formatINR } from '@/lib/cart-context';
import { toast } from 'sonner';
import type { Category, Product, Review } from '@/lib/types';
import { cn } from '@/lib/utils';

interface Props {
  product: Product;
  reviews: Review[];
  related: Product[];
  categories: Category[];
}

export function ProductDetail({ product, reviews, related, categories }: Props) {
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const images = product.images?.length ? product.images : [product.image_url];
  const discount = product.compare_price
    ? Math.round(((product.compare_price - product.price) / product.compare_price) * 100)
    : 0;

  const cat = categories.find((c) => c.id === product.category_id);

  const onAdd = () => {
    add(product, qty);
    toast.success('Added to cart', { description: `${qty} × ${product.name}` });
  };

  const onBuyNow = () => {
    add(product, qty);
    window.location.href = '/cart';
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      {/* Breadcrumb */}
      <nav className="mb-6 flex items-center gap-1 text-xs text-muted-foreground">
        <Link href="/" className="hover:text-primary">Home</Link>
        <ChevronRight className="h-3 w-3" />
        <Link href="/shop" className="hover:text-primary">Shop</Link>
        {cat && (
          <>
            <ChevronRight className="h-3 w-3" />
            <Link href={`/shop?category=${cat.slug}`} className="hover:text-primary">{cat.name}</Link>
          </>
        )}
        <ChevronRight className="h-3 w-3" />
        <span className="truncate text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* Gallery */}
        <div className="flex flex-col gap-4">
          <div className="relative aspect-square overflow-hidden rounded-2xl border bg-secondary">
            <Image
              src={images[activeImage]}
              alt={product.name}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
              priority
            />
            <div className="absolute left-4 top-4 flex flex-col gap-1.5">
              {product.badge && <Badge className="bg-primary text-primary-foreground">{product.badge}</Badge>}
              {discount > 0 && <Badge className="bg-accent text-accent-foreground">-{discount}%</Badge>}
            </div>
          </div>
          {images.length > 1 && (
            <div className="flex gap-3">
              {images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={cn(
                    'relative h-20 w-20 overflow-hidden rounded-lg border-2 transition',
                    i === activeImage ? 'border-primary' : 'border-transparent hover:border-border'
                  )}
                >
                  <Image src={img} alt={`${product.name} ${i + 1}`} fill sizes="80px" className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-accent text-accent" />
              <span className="font-medium text-foreground">{product.rating.toFixed(1)}</span>
            </div>
            <span>·</span>
            <span>{product.reviews_count} reviews</span>
            {product.stock > 0 ? (
              <Badge variant="secondary" className="ml-2 bg-success/15 text-success">{product.stock} in stock</Badge>
            ) : (
              <Badge variant="secondary" className="ml-2 bg-destructive/15 text-destructive">Out of stock</Badge>
            )}
          </div>

          <h1 className="mt-2 font-display text-3xl font-semibold leading-tight sm:text-4xl">{product.name}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{product.description}</p>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="font-display text-3xl font-semibold">{formatINR(Number(product.price))}</span>
            {product.compare_price && (
              <span className="text-lg text-muted-foreground line-through">{formatINR(Number(product.compare_price))}</span>
            )}
            {discount > 0 && <span className="text-sm font-medium text-success">Save {discount}%</span>}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">per {product.unit} · Inclusive of all taxes</p>

          {/* Quantity + actions */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-lg border">
              <button
                aria-label="Decrease quantity"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="flex h-10 w-10 items-center justify-center text-muted-foreground hover:text-foreground"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-10 text-center text-sm font-medium">{qty}</span>
              <button
                aria-label="Increase quantity"
                onClick={() => setQty((q) => Math.min(product.stock || 99, q + 1))}
                className="flex h-10 w-10 items-center justify-center text-muted-foreground hover:text-foreground"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <Button size="lg" onClick={onAdd} disabled={product.stock === 0} className="flex-1 sm:flex-none">
              <ShoppingBag className="mr-2 h-4 w-4" /> Add to cart
            </Button>
            <Button size="lg" variant="secondary" onClick={onBuyNow} disabled={product.stock === 0}>
              Buy now
            </Button>
          </div>

          {/* Trust badges */}
          <div className="mt-6 grid grid-cols-3 gap-3 rounded-xl border bg-secondary/30 p-4 text-center">
            <div className="flex flex-col items-center gap-1">
              <Truck className="h-5 w-5 text-primary" />
              <span className="text-xs">Free shipping<br />over ₹999</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <ShieldCheck className="h-5 w-5 text-primary" />
              <span className="text-xs">Secure<br />payments</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RefreshCw className="h-5 w-5 text-primary" />
              <span className="text-xs">Easy returns<br />within 48h</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="description" className="w-full">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
            <TabsTrigger value="shipping">Shipping</TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="mt-6 max-w-3xl text-sm leading-relaxed text-foreground/85">
            {product.long_description ?? product.description}
          </TabsContent>
          <TabsContent value="reviews" className="mt-6">
            <ReviewsList reviews={reviews} productId={product.id} />
          </TabsContent>
          <TabsContent value="shipping" className="mt-6 max-w-3xl text-sm leading-relaxed text-foreground/85">
            <p>Orders are dispatched within 24 hours of placement. Standard delivery takes 3–5 business days. Express delivery is available in select metro cities.</p>
            <p className="mt-3">Due to the perishable nature of our products, returns are accepted only for damaged or incorrect items reported within 48 hours of delivery.</p>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related */}
      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 font-display text-2xl font-semibold">You may also like</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function ReviewsList({ reviews, productId }: { reviews: Review[]; productId: string }) {
  const [showForm, setShowForm] = useState(false);
  return (
    <div className="grid gap-8 md:grid-cols-[1fr_320px]">
      <div>
        {reviews.length === 0 ? (
          <div className="rounded-xl border border-dashed p-8 text-center">
            <p className="text-sm text-muted-foreground">No reviews yet. Be the first to share your experience!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {reviews.map((r) => (
              <div key={r.id} className="rounded-xl border bg-card p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                      {r.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{r.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(r.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={cn('h-4 w-4', i < r.rating ? 'fill-accent text-accent' : 'text-muted-foreground/30')} />
                    ))}
                  </div>
                </div>
                {r.title && <p className="mt-3 text-sm font-medium">{r.title}</p>}
                {r.body && <p className="mt-1 text-sm text-muted-foreground">{r.body}</p>}
              </div>
            ))}
          </div>
        )}
      </div>

      <aside>
        <div className="rounded-xl border bg-secondary/30 p-5">
          <h3 className="font-display text-lg font-semibold">Write a review</h3>
          <p className="mt-1 text-xs text-muted-foreground">Share your thoughts with other customers</p>
          {showForm ? (
            <ReviewForm productId={productId} onDone={() => setShowForm(false)} />
          ) : (
            <Button className="mt-4 w-full" onClick={() => setShowForm(true)}>
              Write a review
            </Button>
          )}
        </div>
      </aside>
    </div>
  );
}
