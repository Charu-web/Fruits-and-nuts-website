'use client';

import { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export function ReviewForm({ productId, onDone }: { productId: string; onDone: () => void }) {
  const [name, setName] = useState('');
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error('Please enter your name');
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from('reviews').insert({
      product_id: productId,
      name: name.trim(),
      rating,
      title: title.trim() || null,
      body: body.trim() || null,
      approved: false,
    });
    setSubmitting(false);
    if (error) {
      toast.error('Could not submit review', { description: 'Please try again later.' });
      return;
    }
    toast.success('Review submitted!', { description: 'It will appear once approved by our team.' });
    onDone();
  };

  return (
    <form onSubmit={onSubmit} className="mt-4 space-y-3">
      <div>
        <Label htmlFor="r-name" className="text-xs">Your name</Label>
        <Input id="r-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Aarav S." required className="mt-1 h-9 bg-card" />
      </div>
      <div>
        <Label className="text-xs">Rating</Label>
        <div className="mt-1 flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              aria-label={`Rate ${n}`}
              onClick={() => setRating(n)}
              className="p-0.5"
            >
              <Star className={cn('h-6 w-6', n <= rating ? 'fill-accent text-accent' : 'text-muted-foreground/40')} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <Label htmlFor="r-title" className="text-xs">Title (optional)</Label>
        <Input id="r-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Sum up your experience" className="mt-1 h-9 bg-card" />
      </div>
      <div>
        <Label htmlFor="r-body" className="text-xs">Review (optional)</Label>
        <Textarea id="r-body" value={body} onChange={(e) => setBody(e.target.value)} placeholder="What did you like or dislike?" className="mt-1 bg-card" rows={3} />
      </div>
      <Button type="submit" className="w-full" disabled={submitting}>
        {submitting ? 'Submitting…' : 'Submit review'}
      </Button>
    </form>
  );
}
