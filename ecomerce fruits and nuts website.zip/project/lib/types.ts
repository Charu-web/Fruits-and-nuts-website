export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  sort_order: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  long_description: string | null;
  price: number;
  compare_price: number | null;
  image_url: string;
  images: string[];
  category_id: string | null;
  stock: number;
  unit: string;
  badge: string | null;
  is_featured: boolean;
  is_bestseller: boolean;
  is_new: boolean;
  rating: number;
  reviews_count: number;
  sort_order: number;
  created_at: string;
}

export interface ProductWithCategory extends Product {
  category?: Pick<Category, 'id' | 'name' | 'slug'> | null;
}

export interface Review {
  id: string;
  product_id: string;
  name: string;
  rating: number;
  title: string | null;
  body: string | null;
  approved: boolean;
  created_at: string;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string;
  cta_text: string | null;
  cta_link: string | null;
  sort_order: number;
  active: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'percentage' | 'flat' | 'free_shipping';
  value: number;
  min_order: number;
  expiry: string | null;
  usage_limit: number | null;
  used_count: number;
  active: boolean;
}

export interface OrderItem {
  product_id: string;
  name: string;
  slug: string;
  price: number;
  quantity: number;
  image_url: string;
  unit: string;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string | null;
  pincode: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  coupon_code: string | null;
  payment_method: string;
  status: string;
  created_at: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
