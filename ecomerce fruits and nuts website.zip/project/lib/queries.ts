import { supabase } from '@/lib/supabase';
import type { Banner, Category, Product, Review } from '@/lib/types';

export async function getBanners(): Promise<Banner[]> {
  const { data } = await supabase
    .from('banners')
    .select('*')
    .eq('active', true)
    .order('sort_order', { ascending: true });
  return (data as Banner[]) ?? [];
}

export async function getCategories(): Promise<Category[]> {
  const { data } = await supabase
    .from('categories')
    .select('*')
    .order('sort_order', { ascending: true });
  return (data as Category[]) ?? [];
}

export async function getFeaturedProducts(limit = 8): Promise<Product[]> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .eq('is_featured', true)
    .order('sort_order', { ascending: true })
    .limit(limit);
  return (data as Product[]) ?? [];
}

export async function getBestsellers(limit = 8): Promise<Product[]> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .eq('is_bestseller', true)
    .order('reviews_count', { ascending: false })
    .limit(limit);
  return (data as Product[]) ?? [];
}

export async function getNewArrivals(limit = 8): Promise<Product[]> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .eq('is_new', true)
    .order('created_at', { ascending: false })
    .limit(limit);
  return (data as Product[]) ?? [];
}

export async function getAllProducts(): Promise<Product[]> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .order('sort_order', { ascending: true });
  return (data as Product[]) ?? [];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .eq('slug', slug)
    .maybeSingle();
  return (data as Product) ?? null;
}

export async function getReviewsForProduct(productId: string): Promise<Review[]> {
  const { data } = await supabase
    .from('reviews')
    .select('*')
    .eq('product_id', productId)
    .eq('approved', true)
    .order('created_at', { ascending: false });
  return (data as Review[]) ?? [];
}

export async function getRelatedProducts(categoryId: string, excludeId: string, limit = 4): Promise<Product[]> {
  const { data } = await supabase
    .from('products')
    .select('*')
    .eq('category_id', categoryId)
    .neq('id', excludeId)
    .limit(limit);
  return (data as Product[]) ?? [];
}
